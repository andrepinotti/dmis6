package com.example.todolist;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class TaskListActivity extends AppCompatActivity implements TaskAdapter.OnTaskActionListener {
    private RecyclerView recyclerView;
    private TaskAdapter adapter;
    private ArrayList<String> tasks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_list);

        recyclerView = findViewById(R.id.recycler_view_task);

        // Carregar tarefas
        loadTasks();

        // Configurar RecyclerView
        adapter = new TaskAdapter(tasks, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Configurar ItemTouchHelper para deslizar
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                if (direction == ItemTouchHelper.LEFT) {
                    // Excluir tarefa
                    deleteTask(position);
                } else if (direction == ItemTouchHelper.RIGHT) {
                    // Editar tarefa
                    editTask(position);
                }
            }
        });

        itemTouchHelper.attachToRecyclerView(recyclerView);
    }

    private void loadTasks() {
        SharedPreferences sharedPreferences = getSharedPreferences("ToDoList", MODE_PRIVATE);
        Set<String> taskSet = sharedPreferences.getStringSet("tasks", new HashSet<>());
        tasks = new ArrayList<>(taskSet);
    }

    private void saveTasks() {
        SharedPreferences sharedPreferences = getSharedPreferences("ToDoList", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Set<String> taskSet = new HashSet<>(tasks);
        editor.putStringSet("tasks", taskSet);
        editor.apply();
    }

    private void deleteTask(int position) {
        // pega o nome da tarefa
        String task = tasks.get(position);

        tasks.remove(position);
        adapter.notifyItemRemoved(position);

        // Atualiza o SharedPreferences para refletir a remoção
        SharedPreferences sharedPreferences = getSharedPreferences("ToDoList", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // Converte a lista de tarefas para um conjunto (Set) para armazenar no SharedPreferences
        Set<String> taskSet = new HashSet<>(tasks);
        editor.putStringSet("tasks", taskSet);
        editor.apply();

        // excluído
        Toast.makeText(this, "Tarefa excluída: " + task, Toast.LENGTH_SHORT).show();
    }

    private void editTask(int position) {
        String task = tasks.get(position);
        Intent intent = new Intent(this, AddTaskActivity.class);
        intent.putExtra("task", task);
        intent.putExtra("position", position);
        startActivity(intent);
    }

    @Override
    public void onEditTask(int position) {
        editTask(position);
    }

    @Override
    public void onDeleteTask(int position) {
        deleteTask(position);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadTasks();
        adapter.notifyDataSetChanged();
    }
}
