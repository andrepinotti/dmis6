package com.example.todolist;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Set;
import android.content.Intent;


public class MainActivity extends AppCompatActivity {
    private TextView tvTaskInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvTaskInfo = findViewById(R.id.tv_task_info);
        Button btnAddTask = findViewById(R.id.btn_add_task);
        Button btnViewTasks = findViewById(R.id.btn_view_tasks);

        // Carrega o número de tarefas
        loadTaskInfo();

        // Configura os botões
        btnAddTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AddTaskActivity.class));
            }
        });

        btnViewTasks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, TaskListActivity.class));
            }
        });
    }

    private void loadTaskInfo() {
        SharedPreferences sharedPreferences = getSharedPreferences("ToDoList", MODE_PRIVATE);
        Set<String> tasks = sharedPreferences.getStringSet("tasks", null);

        if (tasks == null || tasks.isEmpty()) {
            tvTaskInfo.setText("Nenhuma tarefa cadastrada no momento.");
        } else {
            int taskCount = tasks.size();
            tvTaskInfo.setText("Você tem " + taskCount + (taskCount == 1 ? " tarefa" : " tarefas") + ".");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Atualiza o número de tarefas ao retornar para a tela principal
        loadTaskInfo();
    }
}

