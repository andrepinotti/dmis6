package com.example.todolist;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.DatePicker;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.app.ActionBar;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class AddTaskActivity extends AppCompatActivity {

    private EditText edtTaskName;
    private Button btnSaveTask;
    private RadioGroup radioPriority;
    private DatePicker datePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task); // Certifique-se que o layout está correto

        edtTaskName = findViewById(R.id.edt_task_name);
        btnSaveTask = findViewById(R.id.btn_save_task);
        radioPriority = findViewById(R.id.radio_priority);
        datePicker = findViewById(R.id.date_picker);

        btnSaveTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTask();
            }
        });
    }

    private void saveTask() {
        String taskName = edtTaskName.getText().toString().trim();

        if (taskName.isEmpty()) {
            Toast.makeText(this, "Por favor, insira o nome da tarefa.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Obter a prioridade selecionada
        int selectedPriorityId = radioPriority.getCheckedRadioButtonId();
        String priority = "Baixa"; // Padrão

        if (selectedPriorityId == R.id.radio_high) {
            priority = "Alta";
        } else if (selectedPriorityId == R.id.radio_medium) {
            priority = "Média";
        }

        // Obter a data escolhida
        int day = datePicker.getDayOfMonth();
        int month = datePicker.getMonth();
        int year = datePicker.getYear();
        String date = day + "/" + (month + 1) + "/" + year; // Formato: dd/mm/yyyy

        // Salvar tarefa no SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("ToDoList", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // Criar uma string que descreve a tarefa
        String taskDetails = taskName + " | Prioridade: " + priority + " | Data: " + date;

        // Recuperar tarefas existentes
        Set<String> tasks = sharedPreferences.getStringSet("tasks", new HashSet<>());
        tasks.add(taskDetails); // Adiciona a nova tarefa

        // Salvar as tarefas atualizadas
        editor.putStringSet("tasks", tasks);
        editor.apply();

        // Mostrar mensagem de sucesso
        Toast.makeText(this, "Tarefa salva com sucesso!", Toast.LENGTH_SHORT).show();

        finish(); // Voltar para a tela anterior
    }
}
